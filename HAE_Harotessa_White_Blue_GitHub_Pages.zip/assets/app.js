
document.getElementById('year').textContent=new Date().getFullYear();
const menu=document.querySelector('.menu'),nav=document.querySelector('nav');
menu?.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')==='true';menu.setAttribute('aria-expanded',String(!open));nav.style.display=open?'none':'flex';nav.style.flexDirection='column';nav.style.position='absolute';nav.style.top='68px';nav.style.right='4%';nav.style.background='#fff';nav.style.padding='18px';nav.style.borderRadius='16px';nav.style.boxShadow='0 15px 35px rgba(0,0,0,.15)'});
function loadVideo(){const u=document.getElementById('videoUrl').value.trim();if(!u)return;document.querySelector('#player iframe').src=u;document.getElementById('player').hidden=false}
function sendMail(e){e.preventDefault();const n=document.getElementById('name').value,em=document.getElementById('email').value,m=document.getElementById('message').value;location.href='mailto:harotessa@gmail.com?subject='+encodeURIComponent('Website enquiry from '+n)+'&body='+encodeURIComponent(m+'\n\nReply to: '+em)}
