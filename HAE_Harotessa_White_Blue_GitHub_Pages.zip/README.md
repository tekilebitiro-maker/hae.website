# Harotessa Association Ethiopia (HAE) website
Static, responsive GitHub Pages website based on the HAE Organizational Profile (updated August 2025).
## Publish
1. Create a GitHub repository (public), e.g. `hae-website`.
2. Upload all files preserving the `assets/` folder.
3. GitHub → Settings → Pages → Deploy from branch → `main` / root.
4. Your Pages URL will be `https://YOUR-USERNAME.github.io/hae-website/`.
## Custom domain
After the Pages site is live, add `harotessa.org` in Settings → Pages → Custom domain, then configure DNS at the domain registrar as GitHub instructs. HTTPS can then be enabled by GitHub.
## Video portal
The featured video accepts an embeddable YouTube/Vimeo URL. Replace/add videos in `index.html` as desired.
