# HAE website — 5-minute GitHub Pages deployment

1. Create a **public** GitHub repository, e.g. `hae-website`.
2. Upload the contents of this folder (including `CNAME`, `assets/`, and `index.html`).
3. GitHub: **Settings → Pages → Deploy from branch → main → /(root) → Save**.
4. GitHub Pages will publish the site at a `github.io` address.
5. The included `CNAME` file requests **harotessa.org**.
6. In your domain DNS, configure the apex records recommended by GitHub Pages and a `www` CNAME to your GitHub Pages hostname.
7. In GitHub Pages, enable HTTPS after DNS has propagated.

GitHub notes that DNS changes can take up to 24 hours. Do not claim the custom domain is live until DNS and GitHub Pages are actually showing the site.
